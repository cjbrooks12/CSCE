#include "Record.h"
#include "TemplateDoublyLinkedList.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cstdio>
#include <sstream>
#include <vector>
using namespace std;

namespace phone_book {
	vector<DoublyLinkedList<Record>> phonebook;
	DoublyLinkedList<Record> pages;
	const char letters[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 
		'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
		
	// void print_vector(vector<Record> r) {
		// for(int i = 0; i < r.size(); ++i) {
			// cout << r[i] << endl;
		// }
	// }
		
	void quit() {
		
	}
	
	void display_all() {
		cout << "you selected all\n";
	}
	
	void display_page(int page) {
		cout << "-------------------------------------------------------------------------------\n"
		<< "* * " << letters[page] << " * * \n"
		<< "-------------------------------------------------------------------------------\n"
		<< phonebook[page]
		<< "-------------------------------------------------------------------------------\n\n\n";
	}
	
	void display_name(string name) {
	
	}
	
	void select_display() {
		string decision, name;
		char letter;
		
		cout << ">";
		cin >> decision;
		
		if(decision == "all") {
			quit();
		}
		if(decision == "all") {
			display_all();
		}
		if(decision == "page") {
			cin >> letter;
			letter = toupper(letter);
			bool found = false;
			int i = 0;
			while(!found) {
				if(letter == letters[i]) {
					found = true;
				}
				else {
					++i;
				}
				if(i > 26) {
					cout << "Please enter valid letters only\n";
					i = 0;
					select_display();
				}
			}
			display_page(i);
		}
		if(decision == "name") {
			cin >> name;
			display_name(name);
		}
		
	}
	
	void display_phone_book() {
		cout << "Your personal phonebook \n" 
			<< "    -Entries are sorted by last name, first name, and then UIN \n" 
			<< "    -To display the entire phonebook, enter 'all' \n"
			<< "    -To narrow your search by letter of last name, enter 'page' followed by the letter \n"
			<< "    -To search for a specific name, enter 'name' followed by the name \n" 
			<< "    -To quit, type 'quit'\n\n\n";
		select_display();
	}
	
	void populate_phonebook() {
		for(int i = 0; i < 26; ++i) {
			DoublyLinkedList<Record> list;
			phonebook.push_back(list);
		}
	
		ifstream ifs("PhoneBook.txt");
		char fl; //first letter of the last name
		while(!ifs.eof()) {
			Record rr;
			ifs >> rr;
			
			//Determine which list to add this Record to
			int i = 0;
			if(rr.last_name.size() > 0) {
				fl = rr.last_name.at(0);
				bool found = false;
				while(!found) {
					if(fl == letters[i]) {
						found = true;
					}
					else {
						++i;
					}
				}
				phonebook[i].insertLast(rr);
			}
		}
		ifs.close();
	}
	
	void start() {
		populate_phonebook();
		display_phone_book();
	}
};

int main() {
	phone_book::start();

	return 0;
}