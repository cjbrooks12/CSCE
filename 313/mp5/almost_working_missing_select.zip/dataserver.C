#include <cassert>
#include <cstring>
#include <iostream>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <vector>
#include <sstream>


#include "NetworkRequestChannel.H"

using namespace std;

char* port_number;
int backlog;
vector<pthread_t*> clients;
vector<int> client_fds;


//Main server-side program, receives and returns data from clients in new threads
//------------------------------------------------------------------------------
string to_string(int number) {
   stringstream ss;//create a stringstream
   ss << number;//add number to the stream
   return ss.str();//return a string with the contents of the stream
}

string process_string(char* input) {
    string request(input);

    usleep(1000 + (rand() % 5000));

    if (request.compare(0, 5, "hello") == 0) {
        return "Hello to you too!";
    }
    else if (request.compare(0, 4, "data") == 0) {
        return to_string(rand() % 100);
    }
    else {
        return "unknown request";
    }
}

void* server_request_handler(void* argument) { 
    int client_no = *((int*) argument) - 1; 
    int file_des = client_fds[client_no];

    char buf[255];

    while(strcmp(buf, "quit") != 0) {
        memset(buf, 0, sizeof(buf));
        if(recv(file_des, buf, 255, 0) == -1) {
            perror("recv() error");
        }
        else {
            string to_return = process_string(buf); 
            cout << buf << " - " << to_return << "\n";

            if(send(file_des, to_return.c_str(), to_return.size(), 0) == -1) {
                perror("send() error");
            }
        }
    }

    return NULL;
}

//Parse Command Line Arguments
//------------------------------------------------------------------------------
void print_CLA_error() {
    cout << "Error: program needs arguments in the following format with positive integer arguments:\n" <<
            "\t-p <port number for data server>\n" <<
			"\t-b <backlog of the server socket>\n";
}

int parse_CLA(int argc, char* argv[]) {
    if(argc != 5) {
        print_CLA_error(); //If incorrect number of arguments, program must exit
        return -1;
    }
    else {
        int correct_args = 0;
        for(int i = 0; i < argc; i++) {
            if(argv[i] == string("-b")) {
                correct_args++;
                backlog = atoi(argv[i+1]);
                assert(backlog != 0);
            }
            if(argv[i] == string("-p")) {
                correct_args++;
                port_number = argv[i+1];
                assert(port_number != NULL);
            }
        }
        if(correct_args != 2) { //if arguments are incorrect, program must exit
            print_CLA_error();
            return -1;
        }
    }
    return 0;
}

//Main Function
//------------------------------------------------------------------------------
// void sigchld_handler(int s) {
//     while(waitpid(-1, NULL, WNOHANG) > 0);
// }

// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa) {
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }
    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

int main(int argc, char * argv[]) {
	if(parse_CLA(argc, argv) == -1) {
        return -1;
    }

    //Beginning of main code from Beej's guide

    int sockfd; // listen on sock_fd, new connection on m_new_fd
    struct addrinfo hints, *servinfo, *p;
    struct sockaddr_storage their_addr; // connector's address information
    socklen_t sin_size;
    // struct sigaction sa;
    int yes=1;
    char s[INET6_ADDRSTRLEN];
    int rv;

    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE; // use my IP

    if ((rv = getaddrinfo(NULL, port_number, &hints, &servinfo)) != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
        return 1;
    }

    // loop through all the results and bind to the first we can
    for(p = servinfo; p != NULL; p = p->ai_next) {
        if ((sockfd = socket(p->ai_family, p->ai_socktype,
            p->ai_protocol)) == -1) {
            perror("server: socket");
        continue;
        }
        if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes,
            sizeof(int)) == -1) {
            perror("setsockopt");
        exit(1);
        }
        if (bind(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
            close(sockfd);
            perror("server: bind");
            continue;
        }
        break;
    }

    if(p == NULL) {
        fprintf(stderr, "server: failed to bind\n");
        return 2;
    }
    freeaddrinfo(servinfo); // all done with this structure

    if(listen(sockfd, backlog) == -1) {
        perror("listen");
        exit(1);
    }

    printf("server: waiting for connections...\n");

    while(true) { // main accept() loop
        int *client_no = (int*) malloc(sizeof(int));
        *client_no = clients.size();

        sin_size = sizeof their_addr;
        client_fds.push_back(accept(sockfd, (struct sockaddr *)&their_addr, &sin_size));
        
        if(client_fds[*client_no] == -1) {
            perror("accept");
            continue;
        }
       
        inet_ntop(their_addr.ss_family, get_in_addr((struct sockaddr *)&their_addr), s, sizeof s);
        cout << "server: got connection from " << s << "\n";

        clients.push_back(new pthread_t);
        pthread_create(clients[*client_no], NULL, server_request_handler, (void*) client_no);
        free(client_no);
    }

    for(int i = 0; i < clients.size(); i++) {
        pthread_join(*clients[i], NULL);
    }

    return 0;
}